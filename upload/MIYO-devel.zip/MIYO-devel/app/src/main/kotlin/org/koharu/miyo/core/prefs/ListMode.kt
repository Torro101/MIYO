package org.koharu.miyo.core.prefs

import androidx.annotation.Keep

@Keep
enum class ListMode {

	LIST, DETAILED_LIST, GRID, COVER_ONLY;
}
