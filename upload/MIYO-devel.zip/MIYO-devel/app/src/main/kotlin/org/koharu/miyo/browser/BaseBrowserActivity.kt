package org.koharu.miyo.browser

import android.os.Bundle
import android.view.View
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import androidx.lifecycle.lifecycleScope
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.runInterruptible
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.koharu.miyo.core.model.MangaSource as mangaSourceOf
import org.koharu.miyo.core.nav.AppRouter
import org.koharu.miyo.core.network.CommonHeaders
import org.koharu.miyo.core.network.cookies.MutableCookieJar
import org.koharu.miyo.core.network.proxy.ProxyProvider
import org.koharu.miyo.core.network.webview.adblock.AdBlock
import org.koharu.miyo.core.parser.MangaRepository
import org.koharu.miyo.core.parser.ParserMangaRepository
import org.koharu.miyo.core.ui.BaseActivity
import org.koharu.miyo.core.util.ext.configureForParser
import org.koharu.miyo.core.util.ext.consumeAll
import org.koharu.miyo.databinding.ActivityBrowserBinding
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koitharu.kotatsu.parsers.util.nullIfEmpty
import javax.inject.Inject

@AndroidEntryPoint
abstract class BaseBrowserActivity : BaseActivity<ActivityBrowserBinding>(), BrowserCallback {

	@Inject
	lateinit var proxyProvider: ProxyProvider

	@Inject
	lateinit var mangaRepositoryFactory: MangaRepository.Factory

	@Inject
	lateinit var adBlock: AdBlock

	@Inject
	lateinit var webViewCookieJar: MutableCookieJar

	private lateinit var onBackPressedCallback: WebViewBackPressedCallback

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		if (!setContentViewWebViewSafe { ActivityBrowserBinding.inflate(layoutInflater) }) {
			return
		}
		viewBinding.webView.webChromeClient = ProgressChromeClient(viewBinding.progressBar)
		onBackPressedCallback = WebViewBackPressedCallback(viewBinding.webView)
		onBackPressedDispatcher.addCallback(onBackPressedCallback)

		val mangaSource = mangaSourceOf(intent?.getStringExtra(AppRouter.KEY_SOURCE))
		val repository = mangaRepositoryFactory.create(mangaSource) as? ParserMangaRepository
		val userAgent = intent?.getStringExtra(AppRouter.KEY_USER_AGENT)?.nullIfEmpty()
			?: repository?.getRequestHeaders()?.get(CommonHeaders.USER_AGENT)
		viewBinding.webView.configureForParser(userAgent)

		onCreate2(savedInstanceState, mangaSource, repository)
	}

	protected abstract fun onCreate2(
		savedInstanceState: Bundle?,
		source: MangaSource,
		repository: ParserMangaRepository?
	)

	override fun onApplyWindowInsets(
		v: View,
		insets: WindowInsetsCompat
	): WindowInsetsCompat {
		val type = WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
		val barsInsets = insets.getInsets(type)
		viewBinding.webView.updatePadding(
			left = barsInsets.left,
			right = barsInsets.right,
			bottom = barsInsets.bottom,
		)
		viewBinding.appbar.updatePadding(
			left = barsInsets.left,
			right = barsInsets.right,
			top = barsInsets.top,
		)
		return insets.consumeAll(type)
	}

	override fun onPause() {
		persistWebViewCookiesAsync()
		viewBinding.webView.onPause()
		super.onPause()
	}

	override fun onResume() {
		super.onResume()
		viewBinding.webView.onResume()
	}

	override fun onDestroy() {
		super.onDestroy()
		if (hasViewBinding()) {
			webViewCookieJar.flush()
			viewBinding.webView.stopLoading()
			viewBinding.webView.destroy()
		}
	}

	override fun onLoadingStateChanged(isLoading: Boolean) {
		viewBinding.progressBar.isVisible = isLoading
		if (!isLoading) {
			persistWebViewCookiesAsync()
		}
	}

	override fun onTitleChanged(title: CharSequence, subtitle: CharSequence?) {
		this.title = title
		supportActionBar?.subtitle = subtitle
	}

	override fun onHistoryChanged() {
		onBackPressedCallback.onHistoryChanged()
	}

	protected fun persistWebViewCookiesAsync() {
		val urls = currentCookieUrls()
		if (urls.isEmpty()) {
			return
		}
		lifecycleScope.launch(Dispatchers.Default) {
			for (url in urls) {
				webViewCookieJar.saveFromWebView(url)
			}
			webViewCookieJar.flush()
		}
	}

	protected fun currentCookieUrls(): List<HttpUrl> {
		return listOfNotNull(
			viewBinding.webView.url?.toHttpUrlOrNull(),
			intent?.dataString?.toHttpUrlOrNull(),
		).distinctBy { "${it.host}:${it.port}${it.encodedPath}" }
	}

	protected suspend fun prepareWebViewCookies(url: String?) {
		val httpUrl = url?.toHttpUrlOrNull() ?: return
		runInterruptible(Dispatchers.Default) {
			webViewCookieJar.loadForRequest(httpUrl)
			webViewCookieJar.flush()
		}
	}
}
