package org.koharu.miyo.core.exceptions.resolve

import android.content.Context
import android.widget.Toast
import androidx.activity.result.ActivityResultCaller
import androidx.annotation.StringRes
import androidx.collection.MutableScatterMap
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.fragment.app.FragmentManager
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.suspendCancellableCoroutine
import org.koharu.miyo.R
import org.koharu.miyo.browser.BrowserActivity
import org.koharu.miyo.browser.cloudflare.CloudFlareActivity
import org.koharu.miyo.core.exceptions.CaughtException
import org.koharu.miyo.core.exceptions.CloudFlareProtectedException
import org.koharu.miyo.core.exceptions.EmptyMangaException
import org.koharu.miyo.core.exceptions.InteractiveActionRequiredException
import org.koharu.miyo.core.exceptions.ProxyConfigException
import org.koharu.miyo.core.exceptions.UnsupportedSourceException
import org.koharu.miyo.core.exceptions.WrapperIOException
import org.koharu.miyo.core.nav.AppRouter
import org.koharu.miyo.core.nav.router
import org.koharu.miyo.core.prefs.AppSettings
import org.koharu.miyo.core.ui.dialog.buildAlertDialog
import org.koharu.miyo.core.util.ext.isHttpUrl
import org.koharu.miyo.core.util.ext.restartApplication
import org.koharu.miyo.details.ui.pager.EmptyMangaReason
import org.koitharu.kotatsu.parsers.exception.AuthRequiredException
import org.koitharu.kotatsu.parsers.exception.NotFoundException
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.model.MangaSource
import org.koharu.miyo.scrobbling.common.domain.ScrobblerAuthRequiredException
import org.koharu.miyo.scrobbling.common.ui.ScrobblerAuthHelper
import org.koharu.miyo.settings.sources.auth.SourceAuthActivity
import org.koitharu.kotatsu.parsers.exception.ParseException
import java.security.cert.CertPathValidatorException
import javax.inject.Inject
import javax.inject.Provider
import javax.net.ssl.SSLException
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume

class ExceptionResolver private constructor(
    private val host: Host,
    private val settings: AppSettings,
    private val scrobblerAuthHelperProvider: Provider<ScrobblerAuthHelper>,
) {
    private val continuations = MutableScatterMap<String, Continuation<Boolean>>(1)

    private val browserActionContract = host.registerForActivityResult(BrowserActivity.Contract()) {
        handleActivityResult(BrowserActivity.TAG, it)
    }
    private val sourceAuthContract = host.registerForActivityResult(SourceAuthActivity.Contract()) {
        handleActivityResult(SourceAuthActivity.TAG, it)
    }
    private val cloudflareContract = host.registerForActivityResult(CloudFlareActivity.Contract()) {
        handleActivityResult(CloudFlareActivity.TAG, it)
    }

    fun showErrorDetails(e: Throwable, url: String? = null) {
        host.router.showErrorDialog(e, url)
    }

    suspend fun resolve(e: Throwable): Boolean = host.lifecycleScope.async {
        when (val error = e.resolvableCause()) {
            is CloudFlareProtectedException -> resolveCF(error)
            is AuthRequiredException -> resolveAuthException(error.source)
            is SSLException,
            is CertPathValidatorException -> {
                showSslErrorDialog()
                false
            }

            is InteractiveActionRequiredException -> resolveBrowserAction(error)

            is ProxyConfigException -> {
                host.router.openProxySettings()
                false
            }

            is NotFoundException -> {
                openInBrowser(error.url)
                false
            }

            is ParseException -> {
                if (error.url.isNotEmpty()) {
                    openInBrowser(error.url)
                }
                false
            }

            is EmptyMangaException -> {
                when (error.reason) {
                    EmptyMangaReason.NO_CHAPTERS -> openAlternatives(error.manga)
                    EmptyMangaReason.LOADING_ERROR -> Unit
                    EmptyMangaReason.RESTRICTED -> host.router.openBrowser(error.manga)
                    else -> Unit
                }
                false
            }

            is UnsupportedSourceException -> {
                error.manga?.let { openAlternatives(it) }
                false
            }

            is ScrobblerAuthRequiredException -> {
                val authHelper = scrobblerAuthHelperProvider.get()
                if (authHelper.isAuthorized(error.scrobbler)) {
                    true
                } else {
                    host.withContext {
                        authHelper.startAuth(this, error.scrobbler).onFailure(::showErrorDetails)
                    }
                    false
                }
            }

            else -> false
        }
    }.await()

    private suspend fun resolveBrowserAction(
        e: InteractiveActionRequiredException
    ): Boolean = suspendCancellableCoroutine { cont ->
		if (putContinuation(BrowserActivity.TAG, cont)) {
			cont.invokeOnCancellation { removeContinuation(BrowserActivity.TAG, cont) }
			browserActionContract.launch(e)
		} else {
			cont.resume(false)
		}
	}

    private suspend fun resolveCF(e: CloudFlareProtectedException): Boolean = suspendCancellableCoroutine { cont ->
		if (putContinuation(CloudFlareActivity.TAG, cont)) {
			cont.invokeOnCancellation { removeContinuation(CloudFlareActivity.TAG, cont) }
			cloudflareContract.launch(e)
		} else {
			cont.resume(false)
		}
	}

    private suspend fun resolveAuthException(source: MangaSource): Boolean = suspendCancellableCoroutine { cont ->
		if (putContinuation(SourceAuthActivity.TAG, cont)) {
			cont.invokeOnCancellation { removeContinuation(SourceAuthActivity.TAG, cont) }
			sourceAuthContract.launch(source)
		} else {
			cont.resume(false)
		}
	}

    private fun openInBrowser(url: String) {
        host.router.openBrowser(url, null, null)
    }

    private fun openAlternatives(manga: Manga) {
        host.router.openAlternatives(manga)
    }

    private fun putContinuation(tag: String, continuation: Continuation<Boolean>): Boolean = synchronized(continuations) {
        if (continuations[tag] != null) {
            return@synchronized false
        }
        continuations[tag] = continuation
        true
    }

    private fun removeContinuation(tag: String, continuation: Continuation<Boolean>) = synchronized(continuations) {
        if (continuations[tag] === continuation) {
            continuations.remove(tag)
        }
    }

    private fun handleActivityResult(tag: String, result: Boolean) {
        val continuation = synchronized(continuations) {
            continuations.remove(tag)
        }
        continuation?.resume(result)
    }

    private fun showSslErrorDialog() {
        val ctx = host.context ?: return
        if (settings.isSSLBypassEnabled) {
            Toast.makeText(ctx, R.string.operation_not_supported, Toast.LENGTH_SHORT).show()
            return
        }
        buildAlertDialog(ctx) {
            setTitle(R.string.ignore_ssl_errors)
            setMessage(R.string.ignore_ssl_errors_summary)
            setPositiveButton(R.string.apply) { _, _ ->
                settings.isSSLBypassEnabled = true
                Toast.makeText(ctx, R.string.settings_apply_restart_required, Toast.LENGTH_LONG).show()
                ctx.restartApplication()
            }
            setNegativeButton(android.R.string.cancel, null)
        }.show()
    }

    class Factory @Inject constructor(
        private val settings: AppSettings,
        private val scrobblerAuthHelperProvider: Provider<ScrobblerAuthHelper>,
    ) {

        fun create(fragment: Fragment) = ExceptionResolver(
            host = Host.FragmentHost(fragment),
            settings = settings,
            scrobblerAuthHelperProvider = scrobblerAuthHelperProvider,
        )

        fun create(activity: FragmentActivity) = ExceptionResolver(
            host = Host.ActivityHost(activity),
            settings = settings,
            scrobblerAuthHelperProvider = scrobblerAuthHelperProvider,
        )
    }

    private sealed interface Host : ActivityResultCaller, LifecycleOwner {

        val context: Context?

        val router: AppRouter

        val fragmentManager: FragmentManager

        inline fun withContext(block: Context.() -> Unit) {
            context?.apply(block)
        }

        class ActivityHost(val activity: FragmentActivity) : Host,
            ActivityResultCaller by activity,
            LifecycleOwner by activity {

            override val context: Context
                get() = activity

            override val router: AppRouter
                get() = activity.router

            override val fragmentManager: FragmentManager
                get() = activity.supportFragmentManager
        }

        class FragmentHost(val fragment: Fragment) : Host,
            ActivityResultCaller by fragment {

            override val context: Context?
                get() = fragment.context

            override val router: AppRouter
                get() = fragment.router

            override val fragmentManager: FragmentManager
                get() = fragment.childFragmentManager

            override val lifecycle: Lifecycle
                get() = fragment.viewLifecycleOwner.lifecycle
        }
    }

    companion object {

        @StringRes
        fun getResolveStringId(e: Throwable) = when (val error = e.resolvableCause()) {
            is CloudFlareProtectedException -> R.string.captcha_solve
            is ScrobblerAuthRequiredException,
            is AuthRequiredException -> R.string.sign_in

            is NotFoundException -> if (error.url.isNotEmpty()) R.string.open_in_browser else 0
            is ParseException -> if (error.url.isNotEmpty()) R.string.open_in_browser else 0
            is UnsupportedSourceException -> if (error.manga != null) R.string.alternatives else 0
            is SSLException,
            is CertPathValidatorException -> R.string.fix

            is ProxyConfigException -> R.string.settings

            is InteractiveActionRequiredException -> R.string._continue

            is EmptyMangaException -> when (error.reason) {
                EmptyMangaReason.RESTRICTED -> if (error.manga.publicUrl.isHttpUrl()) R.string.open_in_browser else 0
                EmptyMangaReason.NO_CHAPTERS -> R.string.alternatives
                else -> 0
            }

            else -> 0
        }

        fun canResolve(e: Throwable) = getResolveStringId(e) != 0
    }
}

private tailrec fun Throwable.resolvableCause(): Throwable = when (this) {
    is CancellationException -> cause?.resolvableCause() ?: this
    is CaughtException -> cause.resolvableCause()
    is WrapperIOException -> cause.resolvableCause()
    is java.io.IOException -> cause?.resolvableCause() ?: this
    else -> this
}
