package org.koharu.miyo.alternatives.domain

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.flow.lastOrNull
import kotlinx.coroutines.flow.runningFold
import kotlinx.coroutines.flow.transformWhile
import kotlinx.coroutines.flow.withIndex
import kotlinx.coroutines.launch
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import org.koharu.miyo.core.model.parcelable.ParcelableManga
import org.koharu.miyo.core.parser.MangaDataRepository
import org.koharu.miyo.core.parser.MangaRepository
import org.koharu.miyo.core.util.ext.concat
import org.koitharu.kotatsu.parsers.model.Manga
import org.koitharu.kotatsu.parsers.util.runCatchingCancellable
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import kotlin.coroutines.cancellation.CancellationException

class AutoFixUseCase @Inject constructor(
	private val mangaRepositoryFactory: MangaRepository.Factory,
	private val alternativesUseCase: AlternativesUseCase,
	private val migrateUseCase: MigrateUseCase,
	private val mangaDataRepository: MangaDataRepository,
) {

	suspend operator fun invoke(mangaId: Long): Pair<Manga, Manga?> {
		val seed = checkNotNull(
			mangaDataRepository.findMangaById(mangaId, withChapters = true),
		) { "Manga $mangaId not found" }.getDetailsSafe()
		if (seed.isHealthy()) {
			return seed to null // no fix required
		}
		val replacement = alternativesUseCase(seed, throughDisabledSources = false)
			.concat(alternativesUseCase(seed, throughDisabledSources = true))
			.filter { it.score.isAutoMigrationSafe && it.manga.isHealthy() }
			.runningFold<AlternativeCandidate, AlternativeCandidate?>(null) { best, candidate ->
				if (best == null || best < candidate) {
					candidate
				} else {
					best
				}
			}.selectLastWithTimeout(4, 40, TimeUnit.SECONDS)
			?.manga
		migrateUseCase(seed, replacement ?: throw NoAlternativesException(ParcelableManga(seed)))
		return seed to replacement
	}

	private suspend fun Manga.isHealthy(): Boolean = runCatchingCancellable {
		val repo = mangaRepositoryFactory.create(source)
		val details = if (this.chapters != null) this else repo.getDetails(this)
		val firstChapter = details.chapters?.firstOrNull() ?: return@runCatchingCancellable false
		val pageUrl = repo.getPageUrl(repo.getPages(firstChapter).first())
		pageUrl.toHttpUrlOrNull() != null
	}.getOrDefault(false)

	private suspend fun Manga.getDetailsSafe() = runCatchingCancellable {
		mangaRepositoryFactory.create(source).getDetails(this)
	}.getOrDefault(this)

	private operator fun AlternativeCandidate.compareTo(other: AlternativeCandidate): Int {
		val scoreCompare = score.value.compareTo(other.score.value)
		return if (scoreCompare != 0) {
			scoreCompare
		} else {
			// Chapter count closeness is already represented by chapterScore; use
			// that instead of preferring the candidate with the largest catalogue.
			score.chapterScore.compareTo(other.score.chapterScore)
		}
	}

	@Suppress("UNCHECKED_CAST", "OPT_IN_USAGE")
	private suspend fun <T> Flow<T>.selectLastWithTimeout(
		minCount: Int,
		timeout: Long,
		timeUnit: TimeUnit
	): T? = channelFlow<T?> {
		var lastValue: T? = null
		launch {
			delay(timeUnit.toMillis(timeout))
			close(InternalTimeoutException(lastValue))
		}
		withIndex().transformWhile { (index, value) ->
			lastValue = value
			emit(value)
			index < minCount && !isClosedForSend
		}.collect {
			send(it)
		}
	}.catch { e ->
		if (e is InternalTimeoutException) {
			emit(e.value as T?)
		} else {
			throw e
		}
	}.lastOrNull()

	class NoAlternativesException(val seed: ParcelableManga) : NoSuchElementException()

	private class InternalTimeoutException(val value: Any?) : CancellationException()
}
