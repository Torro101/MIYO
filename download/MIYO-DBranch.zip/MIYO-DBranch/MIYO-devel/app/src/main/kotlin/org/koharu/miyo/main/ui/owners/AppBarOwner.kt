package org.koharu.miyo.main.ui.owners

import com.google.android.material.appbar.AppBarLayout

interface AppBarOwner {

	val appBar: AppBarLayout
}
