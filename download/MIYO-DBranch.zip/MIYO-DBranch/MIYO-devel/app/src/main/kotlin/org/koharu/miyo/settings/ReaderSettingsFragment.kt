package org.koharu.miyo.settings

import android.content.SharedPreferences
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.preference.ListPreference
import androidx.preference.MultiSelectListPreference
import androidx.preference.Preference
import dagger.hilt.android.AndroidEntryPoint
import org.koharu.miyo.R
import org.koharu.miyo.core.model.ZoomMode
import org.koharu.miyo.core.nav.router
import org.koharu.miyo.core.prefs.AppSettings
import org.koharu.miyo.core.prefs.ReaderAnimation
import org.koharu.miyo.core.prefs.ReaderBackground
import org.koharu.miyo.core.prefs.ReaderControl
import org.koharu.miyo.core.prefs.ReaderMode
import org.koharu.miyo.core.ui.BasePreferenceFragment
import org.koharu.miyo.core.util.ext.setDefaultValueCompat
import org.koharu.miyo.reader.domain.BundledImageRefinementModel
import org.koitharu.kotatsu.parsers.util.mapToSet
import org.koitharu.kotatsu.parsers.util.names
import org.koharu.miyo.settings.utils.MultiSummaryProvider
import org.koharu.miyo.settings.utils.PercentSummaryProvider
import org.koharu.miyo.settings.utils.RefinementModelSettingsHelper
import org.koharu.miyo.settings.utils.SliderPreference
import javax.inject.Inject

@AndroidEntryPoint
class ReaderSettingsFragment :
	BasePreferenceFragment(R.string.reader_settings),
	SharedPreferences.OnSharedPreferenceChangeListener {

	@Inject
	lateinit var refinementModel: BundledImageRefinementModel

	private lateinit var refinementModelHelper: RefinementModelSettingsHelper

	private val importModelsLauncher = registerForActivityResult(
		ActivityResultContracts.OpenDocument(),
	) { uri ->
		if (uri != null && isAdded) {
			refinementModelHelper.importModelsZip(uri)
			findPreference<ListPreference>(AppSettings.KEY_IMAGE_ENHANCEMENT_MODEL)?.let {
				refinementModelHelper.bindModelSummary(it)
			}
		}
	}

	override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
		addPreferencesFromResource(R.xml.pref_reader)
		findPreference<ListPreference>(AppSettings.KEY_READER_MODE)?.run {
			entryValues = ReaderMode.entries.names()
			setDefaultValueCompat(ReaderMode.STANDARD.name)
		}
		findPreference<ListPreference>(AppSettings.KEY_READER_ORIENTATION)?.run {
			entryValues = arrayOf(
				ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED.toString(),
				ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR.toString(),
				ActivityInfo.SCREEN_ORIENTATION_USER_PORTRAIT.toString(),
				ActivityInfo.SCREEN_ORIENTATION_USER_LANDSCAPE.toString(),
			)
			setDefaultValueCompat(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED.toString())
		}
		findPreference<MultiSelectListPreference>(AppSettings.KEY_READER_CONTROLS)?.run {
			entryValues = ReaderControl.entries.names()
			setDefaultValueCompat(ReaderControl.DEFAULT.mapToSet { it.name })
			summaryProvider = MultiSummaryProvider(R.string.none)
		}
		findPreference<ListPreference>(AppSettings.KEY_READER_BACKGROUND)?.run {
			entryValues = ReaderBackground.entries.names()
			setDefaultValueCompat(ReaderBackground.DEFAULT.name)
		}
		findPreference<ListPreference>(AppSettings.KEY_READER_ANIMATION)?.run {
			entryValues = ReaderAnimation.entries.names()
			setDefaultValueCompat(ReaderAnimation.DEFAULT.name)
		}
		findPreference<ListPreference>(AppSettings.KEY_ZOOM_MODE)?.run {
			entryValues = ZoomMode.entries.names()
			setDefaultValueCompat(ZoomMode.FIT_CENTER.name)
		}
		findPreference<MultiSelectListPreference>(AppSettings.KEY_READER_CROP)?.run {
			summaryProvider = MultiSummaryProvider(R.string.disabled)
		}
		findPreference<SliderPreference>(AppSettings.KEY_WEBTOON_ZOOM_OUT)?.summaryProvider = PercentSummaryProvider()
		refinementModelHelper = RefinementModelSettingsHelper(this, refinementModel)
		findPreference<ListPreference>(AppSettings.KEY_IMAGE_ENHANCEMENT_MODEL)?.let { preference ->
			refinementModelHelper.bindModelSummary(preference)
		}
		updateReaderModeDependency()
	}

	override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
		super.onViewCreated(view, savedInstanceState)
		if (!::refinementModelHelper.isInitialized) {
			refinementModelHelper = RefinementModelSettingsHelper(this, refinementModel)
		}
		settings.subscribe(this)
	}

	override fun onDestroyView() {
		settings.unsubscribe(this)
		super.onDestroyView()
	}

	override fun onPreferenceTreeClick(preference: Preference): Boolean {
		return when (preference.key) {
			AppSettings.KEY_READER_TAP_ACTIONS -> {
				router.openReaderTapGridSettings()
				true
			}

			AppSettings.KEY_IMPORT_REFINEMENT_MODELS -> {
				importModelsLauncher.launch(RefinementModelSettingsHelper.IMPORT_MIME_TYPES)
				true
			}

			else -> super.onPreferenceTreeClick(preference)
		}
	}

	override fun onSharedPreferenceChanged(sharedPreferences: SharedPreferences?, key: String?) {
		when (key) {
			AppSettings.KEY_READER_MODE -> updateReaderModeDependency()
			AppSettings.KEY_IMAGE_ENHANCEMENT_MODEL -> {
				findPreference<ListPreference>(key)?.let {
					refinementModelHelper.bindModelSummary(it)
				}
			}
		}
	}

	private fun updateReaderModeDependency() {
		findPreference<Preference>(AppSettings.KEY_READER_MODE_DETECT)?.run {
			isEnabled = settings.defaultReaderMode != ReaderMode.WEBTOON
		}
	}
}
