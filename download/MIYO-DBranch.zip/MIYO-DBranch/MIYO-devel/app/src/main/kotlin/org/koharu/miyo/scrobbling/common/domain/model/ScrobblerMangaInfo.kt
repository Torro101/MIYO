package org.koharu.miyo.scrobbling.common.domain.model

class ScrobblerMangaInfo(
	val id: Long,
	val name: String,
	val cover: String,
	val url: String,
	val descriptionHtml: String,
)
